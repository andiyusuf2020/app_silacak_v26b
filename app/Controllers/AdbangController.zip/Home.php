<?php

namespace App\Controllers;

use \Myth\Auth\Authorization\GroupModel;
use App\Models\UserModel\TaUserModel;
use App\Models\LrfkProvModel\SubKegModel; // as lrfkModel;
use App\Models\LrfkProvModel\RealisasiSubKegModel;
use App\Models\LrfkProvModel\Jadwalmodel;
use App\Models\LrfkProvModel\TaRealPertahunModel;


class Home extends BaseController
{
    protected $subkegmodel;

    protected $realisasilrfk;
    protected $jadwalmodel;
    protected $realpertahun;

    protected $tausermodel;
    public function __construct()
    {
        helper(['form']);
        $this->subkegmodel = new SubKegModel();
        $this->realisasilrfk = new RealisasiSubKegModel();
        $this->jadwalmodel = new Jadwalmodel();
        $this->realpertahun = new TaRealPertahunModel();
        $this->tausermodel = new TaUserModel();
    }
    public function tesX()
    {
        return view('login3');
    }
    public function index()
    {
        return view('index');
    }
    public function log()
    {
        return view('login2');
    }
    public function appprov()
    {
        return view('appportal/appprov');
    }
    public function adbang()
    {
        $data['titlepage'] = 'Selamat Data di e-TAPIS Program Kerja Gubernur dan Wakil Gubernur Lampung 2026-20230';
        $data['groupuser'] = 'adminprogkerja';
        return view('appprov/dashboard', $data);
    }
    public function user()
    {
        if (logged_in()) {
            $user = user();
            $groupModel = new GroupModel();
            $groupuser = $groupModel->getGroupsForUser($user->id);
            foreach ($groupuser as $row) {
                $namagroup = $row['name'];
            }
        }
        $data['titlepage'] = 'Selamat Data di Si-TAPIS Biro Administrasi Pembangunan Setda Provinsi Lampung';
        $data['groupuser'] = $namagroup;
        return view('user/userumum', $data);
    }
    public function lrfkadmin()
    {
        if (logged_in()) {
            $user = user();
            $groupModel = new GroupModel();
            $groupuser = $groupModel->getGroupsForUser($user->id);
            foreach ($groupuser as $row) {
                $namagroup = $row['name'];
            }
        }
        $data['titlepage'] = 'Selamat Data di e-TAPIS Laporan Realisasi Fisik Anggaran Program Kegiatan Perangkat Daerah Provinsi Lampung';
        $data['groupuser'] = $namagroup;
        return view('lrfk/admin/dashboard', $data);
    }
    public function lrfkopd()
    {

        if (logged_in()) {
            $user = user();
            $groupModel = new GroupModel();
            $groupuser = $groupModel->getGroupsForUser($user->id);
            foreach ($groupuser as $row) {
                $namagroup = $row['name'];
            }
        }
        $data['titlepage'] = 'Selamat Data di e-TAPIS Laporan Realisasi Fisik Anggaran Program Kegiatan Perangkat Daerah Provinsi Lampung';
        $data['listopd'] = $this->subkegmodel->listopd();
        $datauser = $this->tausermodel->listuser($user->id);
        if ($datauser['sub_unit'] == '') {
            $data['groupuser'] = 'forbiddenopd';
            return view('lrfk/opd/v_forbidden', $data);
        }

        $data['groupuser'] = $namagroup;
        // return redirect()->to(base_url('lrfkopd'));
        //  return redirect(base_url('lrfkopd'));
        $jadwalaktif = $this->jadwalmodel->jadwalaktifskrg();
        $tahunaktif = $jadwalaktif['tahun'];
        $data['nm_opd'] = $datauser['sub_unit'];
        $data['datarealisasi'] = $this->realisasilrfk->RperTahunOpd($tahunaktif, $datauser['sub_unit']);
        $data['datarealpertahun'] = $this->realpertahun->real($datauser['sub_unit']);
        $belatk = $this->subkegmodel->belatk($datauser['sub_unit']);
        $belcetak = $this->subkegmodel->belcetak($datauser['sub_unit']);
        $belsppd = $this->subkegmodel->belsppd($datauser['sub_unit']);
        $totpaguopd = $this->subkegmodel->totpaguopd2($datauser['sub_unit']);
        $data['atk'] = $belatk['pagu_rincian'] / $totpaguopd['pagu_rincian'] * 100;
        $data['cetak'] = $belcetak['pagu_rincian'] / $totpaguopd['pagu_rincian'] * 100;
        $data['sppd'] = $belsppd['pagu_rincian'] / $totpaguopd['pagu_rincian'] * 100;
        $data['rpatk'] = $belatk['pagu_rincian'];
        $data['rpcetak'] = $belcetak['pagu_rincian'];
        $data['rpsppd'] = $belsppd['pagu_rincian'];

        // echo dd($data['atk']);

        return view('lrfk/opd/dashboard', $data);
    }
}
