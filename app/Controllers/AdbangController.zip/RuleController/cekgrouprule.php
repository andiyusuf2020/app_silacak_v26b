<?php

namespace App\Controllers\RuleController;

use App\Controllers\BaseController;

use \Myth\Auth\Authorization\GroupModel;
use App\Models\UserModel;
use \Myth\Auth\Password;
use App\Models\UserModel\TaUserModel;
use App\Models\adbangmodel\ProgKerjaModel as programkeramodel;

class cekgrouprule extends BaseController
{

    protected $tausermodel;
    protected $Programkerjamodel;
    protected $keyword;

    public function __construct()
    {
        helper(['form']);
        $this->tausermodel = new TaUserModel();
        $this->Programkerjamodel = new programkeramodel();
    }
    public function index()
    {
        if (logged_in()) {
            $user = user();
            $groupModel = new GroupModel();
            $groupuser = $groupModel->getGroupsForUser($user->id);
            foreach ($groupuser as $row) {
                $namagroup = $row['name'];
            }
        }
        if ($namagroup == 'adminprov') {
            return redirect()->to(base_url('lrfkadmin'));
        };
        if ($namagroup == 'userlrfkprov') {
            return redirect()->to(base_url('lrfkopd'));
        };
        if ($namagroup == 'user') {
            return redirect()->to(base_url('user'));
        };
        if ($namagroup == 'usercapkinprov') {
            return redirect()->to(base_url('capkin'));
        };
        // echo $namagroup = $row['name'];
    }
}
