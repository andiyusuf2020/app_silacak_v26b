<?php

namespace App\Controllers\CapKinController;

use App\Models\LrfkProvModel\Jadwalmodel;
use App\Models\UserModel\TaUserModel;
use App\Models\LrfkProvModel\SubKegModel; // as lrfkModel;
use \Myth\Auth\Authorization\GroupModel;
use App\Models\LrfkProvModel\RealisasiSubKegModel;
use App\Models\LrfkProvModel\TotalRealisasiModel;
use App\Models\LrfkProvModel\TaIndikatorProgModal;
use App\Models\LrfkProvModel\TaIndikatorSubKegModal;
use App\Models\LrfkProvModel\TaRealisasiRinciModel;

use App\Models\CapkinModel\TaSubKegCapkinModel;
use App\Models\CapkinModel\TaKegPokokCapkinModel;


use App\Libraries\PdfLibrary;
use App\Controllers\BaseController;
use Dompdf\Dompdf;
use Dompdf\Options;
use FontLib\Table\Type\post;
use PhpOffice\PhpSpreadsheet\Calculation\MathTrig\Sum;
use TCPDF;

class CapKin extends BaseController
{

    protected $jadwalmodel;
    protected $subkegmodel;
    protected $tausermodel;
    protected $realisasilrfk;
    protected $realisasilrfkrinci;

    protected $targetsubkegmodel;
    protected $kegpokokmodal;

    protected $totalrealisasiM;
    protected $tcpdfConfig;
    protected $taindikator;
    protected $taindisubkeg;
    protected $db;
    public function __construct()
    {
        // helper(['form']);
        $this->tausermodel = new TaUserModel();
        $this->jadwalmodel = new Jadwalmodel();
        $this->subkegmodel = new SubKegModel();
        $this->realisasilrfk = new RealisasiSubKegModel();
        $this->totalrealisasiM = new TotalRealisasiModel();
        $this->taindikator = new TaIndikatorProgModal();
        $this->taindisubkeg = new TaIndikatorSubKegModal();
        $this->realisasilrfkrinci = new TaRealisasiRinciModel();

        $this->targetsubkegmodel = new TaSubKegCapkinModel();
        $this->kegpokokmodal = new TaKegPokokCapkinModel();


        $this->tcpdfConfig = new \Config\Tcpdf();
        helper(['form', 'url', 'filesystem']);
        $this->db = db_connect();
    }

    public function index()
    {
        if (logged_in()) {
            $user = user();
            $groupModel = new GroupModel();
            $groupuser = $groupModel->getGroupsForUser($user->id);
            foreach ($groupuser as $row) {
                $namagroup = $row['name'];
            }
        }
        $req = $this->request;
        // Contoh penggunaan parameter
        $receivedParams = $req->getGet();
        $page = $receivedParams['page'] ?? null;
        $action = $receivedParams['action'] ?? null;
        $kdRek = $receivedParams['kdRek'] ?? null;
        $id = $receivedParams['id'] ?? null;
        $kdSK = $receivedParams['kdSK'] ?? null;
        $kdSU = $receivedParams['kdSU'] ?? null;
        $kdU = $receivedParams['kdU'] ?? null;
        $bulan = $receivedParams['bulan'] ?? null;

        $jadwalaktif = $this->jadwalmodel->jadwalaktifskrg();
        $tahunaktif = $jadwalaktif['tahun'];
        $bulanaktif = $jadwalaktif['bulan'];
        session()->set('tahun', $tahunaktif);

        $tahun = session()->get('tahun');

        $data = [
            'groupuser' => $namagroup,
            'titlepage' => 'Selamat Data di e-TAPIS Laporan Capaian Kinerja Output Perangkat Daerah Provinsi Lampung',
            'datauser'  => $this->tausermodel->listuser($user->id),
            'tahun'     => $tahun
        ];
        $ceklrfk = $this->realisasilrfkrinci->cekROpd($data['datauser']['kd_sub_unit'], $tahunaktif);
        if (empty($ceklrfk)) {
            throw new \CodeIgniter\Exceptions\PageNotFoundException('Data Realisasi Anggaran Belum terinput, Mohon diinput..Untuk Melanjutkan');
        }

        // echo dd($data['datauser']);
        if (!$receivedParams) {
            return view('capkin/v_index', $data);
        }
        if ($page == 'dashboard') {
            if ($action == 'listall') {

                $data['dataskcapkinopd'] = $this->targetsubkegmodel->DataPerOpd($tahun, $data['datauser']['kd_sub_unit']);
                // echo dd($data['dataskcapkinopd']);
                return view('capkin/v_datacapkin', $data);
            }
        }
        if ($page == 'data') {
            if ($action == 'tambah') {
                $datask =  $this->subkegmodel->SKKegPokokOPD2($data['datauser']['kd_sub_unit']); //$this->db1->table('ta_agenda_aku')->select('*')->get()->getResult();
                $data['sknoadum'] = ['' => 'pilih']  + array_column($datask, 'nm_subkegiatan', 'kd_subkegiatan');
                $data['kd_subunit'] = $data['datauser']['kd_sub_unit'];
                // $data['sknoadum'] = $this->subkegmodel->SKKegPokokOPD($data['datauser']['kd_sub_unit']);
                // 
                // echo dd($data['subkeg']);
                // return view('capkin/form_inputcapkin', $data);
                return view('capkin/form_pilihsubkeg', $data);
            }
        }
    }
    public function simpancapkin()
    {
        $kdsubkeg = $this->request->getPost('kd_subkegiatan');
        $kdsubunit = $this->request->getPost('kd_subunit');
        $id  = $this->request->getPost('idUbah');
        session()->set('kd_subkegiatan', $kdsubkeg);
        session()->set('kd_subunit', $kdsubunit);
        if ($kdsubkeg) {
            $tahun = session()->get('tahun');
            $datasubkeg = $this->subkegmodel->subkeg($kdsubkeg, $kdsubunit);
            if ($id) {
                $data =  [
                    'id' => $id,
                    'tahun' => $tahun,
                    'kd_subunit' => $kdsubunit,
                    'nm_subunit' => $datasubkeg['nm_sub_unit'],
                    'kd_urusan' => $datasubkeg['kd_urusan'],
                    'kd_program' => $datasubkeg['kd_program'],
                    'kd_kegiatan' => $datasubkeg['kd_kegiatan'],
                    'kd_subkegiatan' => $kdsubkeg,
                    'nm_subkegiatan' => $datasubkeg['nm_subkegiatan'],
                    'pagu' => $datasubkeg['pagu_rincian']
                ];
            } else {
                $data =  [
                    'tahun' => $tahun,
                    'kd_subunit' => $kdsubunit,
                    'nm_subunit' => $datasubkeg['nm_sub_unit'],
                    'kd_urusan' => $datasubkeg['kd_urusan'],
                    'kd_program' => $datasubkeg['kd_program'],
                    'kd_kegiatan' => $datasubkeg['kd_kegiatan'],
                    'kd_subkegiatan' => $kdsubkeg,
                    'nm_subkegiatan' => $datasubkeg['nm_subkegiatan'],
                    'pagu' => $datasubkeg['pagu_rincian']
                ];
            }
            $this->targetsubkegmodel->save($data);
            return redirect()->to(base_url('capkin/kegpokok'));
        }
    }
    public function kegpokok()
    {
        if (logged_in()) {
            $user = user();
            $groupModel = new GroupModel();
            $groupuser = $groupModel->getGroupsForUser($user->id);
            foreach ($groupuser as $row) {
                $namagroup = $row['name'];
            }
        }
        $req = $this->request;
        // Contoh penggunaan parameter
        $receivedParams = $req->getGet();
        $page = $receivedParams['page'] ?? null;
        $action = $receivedParams['action'] ?? null;
        $idUbah = $receivedParams['idUbah'] ?? null;
        $id = $receivedParams['id'] ?? null;
        $kdSK = $receivedParams['kdSK'] ?? null;
        $kdSU = $receivedParams['kdSU'] ?? null;
        $kdU = $receivedParams['kdU'] ?? null;
        $bulan = $receivedParams['bulan'] ?? null;

        $jadwalaktif = $this->jadwalmodel->jadwalaktifskrg();
        $tahunaktif = $jadwalaktif['tahun'];
        $bulanaktif = $jadwalaktif['bulan'];
        session()->set('tahun', $tahunaktif);

        $tahun = session()->get('tahun');


        $kd_sub_unit = session()->get('kd_subunit');
        $kd_subkegiatan = session()->get('kd_subkegiatan');
        $data = [
            'groupuser' => $namagroup,
            'titlepage' => 'Selamat Data di e-TAPIS Laporan Capaian Kinerja Output Perangkat Daerah Provinsi Lampung',
            'datauser'  => $this->tausermodel->listuser($user->id),
            'tahun'     => $tahun
        ];
        if (!$receivedParams) {
            $datasktarget = $this->targetsubkegmodel->cekskcapkin($tahun, $kd_sub_unit, $kd_subkegiatan);
            if ($datasktarget) {
                $data['subkegiatan'] = $datasktarget['nm_subkegiatan'];
                $data['id'] = $datasktarget['id'];
                return view('capkin/form_inputkegpokok', $data);
            }
        }

        if ($page == 'kegpokok') {
            if ($action == 'ubahsubkeg') {
                $datask =  $this->subkegmodel->SKKegPokokOPD2($data['datauser']['kd_sub_unit']); //$this->db1->table('ta_agenda_aku')->select('*')->get()->getResult();
                $data['sknoadum'] = ['' => 'pilih']  + array_column($datask, 'nm_subkegiatan', 'kd_subkegiatan');
                $data['kd_subunit'] = $data['datauser']['kd_sub_unit'];
                $data['idUbah'] = $idUbah;
                // $data['sknoadum'] = $this->subkegmodel->SKKegPokokOPD($data['datauser']['kd_sub_unit']);
                // 
                // echo dd($data['subkeg']);
                // return view('capkin/form_inputcapkin', $data);
                return view('capkin/form_pilihsubkeg', $data);
            }
            if ($action == 'tambah') {
                echo "masuk tambah kegpokok";
            }
        }
    }
    public function simpankegpokok()
    {
        $datakegpokok = $this->request->getPost('data');

        $jumlah = count($datakegpokok); // Mengetahui jumlah elemen
        for ($i = 0; $i < $jumlah; $i++) {
            // if ($datareal[$i]['realisasi'] > $datareal[$i]['pagu_rincian']) {
            //     return redirect()->back()->withInput()->with('message', 'Realisasi  ' . $datareal[$i]['nm_rekening'] . '  melebihi pagu belanja');
            // }
        }
        if ($datakegpokok[0]['id']) {
            // echo dd($datareal);
            $this->kegpokokmodal->updateBatch($datakegpokok, 'id');
            return redirect()->to(base_url('lrfkopd/subkegiatan'))->withInput()->with('message', 'penyimpanan data berhasil');
        } else {
            // echo dd($datareal);
            $this->kegpokokmodal->insertBatch($datakegpokok);
            return redirect()->to(base_url('lrfkopd/subkegiatan'))->withInput()->with('message', 'penyimpanan data berhasil');
        }

        // return redirect()->to(base_url('capkin/kegpokok'));

    }
}
