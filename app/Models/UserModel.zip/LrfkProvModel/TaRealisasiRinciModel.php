<?php

namespace App\Models\LrfkProvModel;

use CodeIgniter\Model;

class TaRealisasiRinciModel extends Model
{
    protected $DBGroup              = 'default';
    protected $table                = 'ta_rinci_realisasi_lrfk';
    protected $primaryKey           = 'id';
    protected $useAutoIncrement     = true;
    protected $useSoftDeletes = true;
    protected $protectFields  = false;
    protected $allowedFields  = [
        'id',
        'kd_urusan',
        'nm_urusan',
        'kd_sub_unit',
        'sub_unit',
        'tahun',
        'bulan',
        'kd_program',
        'nm_program',
        'kd_kegiatan',
        'nm_kegiatan',
        'kd_subkegiatan',
        'nm_subkegiatan',
        'kd_rekbelanja',
        'nm_rekening',
        'pagu_rincian',
        'jenis_belanja ',
        'realisasi',
    ];
    protected $useTimestamps = true; // Tidak menggunakan timestamps
    protected $dateFormat    = 'date';
    protected $createdField  = 'create_at';
    protected $updatedField  = 'update_at';
    protected $deletedField  = 'delete_at';

    public function cekROpd($kd_subunit, $tahun)
    {
        return $this
            ->select('*')
            ->where('kd_sub_unit', $kd_subunit)
            ->where('tahun', $tahun)
            ->where('delete_at=', 0)
            ->get()
            ->getResultArray();
    }

    public function cek($id_real_lrfk)
    {
        return $this
            ->select('*')
            ->where('id_real_lrfk', $id_real_lrfk)
            ->where('delete_at=', 0)
            ->get()
            ->getResultArray();
    }
    public function cekpagu($id_real_lrfk)
    {
        return $this
            ->selectSum('pagu')
            ->selectSum('realisasi')
            ->where('id_real_lrfk', $id_real_lrfk)
            ->where('delete_at=', 0)
            ->groupBy('id_real_lrfk', $id_real_lrfk)
            ->get()
            ->getResultArray();
    }
    public function totalrealperOpd($kdSU, $tahun, $bulan)
    {
        return $this
            ->selectSum('realisasi')
            ->where('kd_sub_unit', $kdSU)
            ->where('tahun', $tahun)
            ->where('bulan', $bulan)
            ->where('delete_at=', 0)
            ->groupBy('kd_sub_unit')
            ->get()
            ->getRowArray();
    }
    public function totalrealperSKpeBln($kdSU, $kdSK, $tahun, $bulan)
    {
        return $this
            ->selectSum('realisasi')
            ->where('kd_sub_unit', $kdSU)
            ->where('tahun', $tahun)
            ->where('bulan', $bulan)
            ->where('kd_subkegiatan', $kdSK)
            ->where('delete_at=', 0)
            ->groupBy('kd_subkegiatan')
            ->get()
            ->getRowArray();
    }
    public function realperSKpeBlnRinci($kdSU, $kdSK, $tahun, $bulan)
    {
        return $this->select('ta_rinci_realisasi_lrfk.*,ta_apbd_perbelanja.kd_rek_belanja,nm_urusan,nm_sub_unit,nm_program,nm_kegiatan')
            ->join(
                'ta_apbd_perbelanja',
                'ta_rinci_realisasi_lrfk.kd_rekbelanja = ta_apbd_perbelanja.kd_rek_belanja',
                'left'
            )
            ->where('ta_apbd_perbelanja.kd_sub_unit', $kdSU)
            ->where('ta_apbd_perbelanja.kd_subkegiatan', $kdSK)
            ->where('ta_rinci_realisasi_lrfk.tahun', $tahun)
            ->where('ta_rinci_realisasi_lrfk.bulan', $bulan)
            ->where('ta_rinci_realisasi_lrfk.delete_at=', 0)
            ->get()
            ->getResultArray();
    }
    public function realperSKpeBlnRinci2($kdSU, $kdSK, $tahun, $bulan)
    {
        return $this
            ->select('*')
            ->where('kd_sub_unit', $kdSU)
            ->where('kd_subkegiatan', $kdSK)
            ->where('tahun', $tahun)
            ->where('bulan', $bulan)
            ->where('delete_at=', 0)
            ->get()
            ->getResultArray();
    }
}
