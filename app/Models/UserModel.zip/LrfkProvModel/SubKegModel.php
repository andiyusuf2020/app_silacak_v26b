<?php

namespace App\Models\LrfkProvModel;

use CodeIgniter\Model;

class SubKegModel extends Model
{

    protected $DBGroup              = 'default';
    //    protected $table                = 'ta_apbd_persubkegiatan';
    // protected $table                = 'ta_apbd_perbelanja';
    protected $table                = 'ta_apbd_perbelanja11';

    protected $primaryKey           = 'id';
    protected $useAutoIncrement = true;

    protected $returnType     = 'array'; // Tipe data yang dikembalikan

    public function TotbelOpd($kdSU)
    {
        return $this
            ->selectCount('kd_rek_belanja')
            ->where('pagu_rincian<>', '0')
            ->where('kd_sub_unit', $kdSU)
            ->get()
            ->getRowArray();
    }

    public function jumlahprogram($tahun, $kd_subunit = null)
    {
        if ($kd_subunit == null) {
            $data = $this
                ->select('nm_program')
                ->where('tahun', $tahun)
                ->where('pagu_rincian<>', '0')
                ->groupBy('nm_program')
                ->get()
                ->getResultArray();
        } else {
            $data = $this
                ->select('nm_program')
                ->where('tahun', $tahun)
                ->where('kd_sub_unit', $kd_subunit)
                ->where('pagu_rincian<>', '0')
                ->groupBy('nm_program')
                ->get()
                ->getResultArray();
        }
        return  $data;
    }
    public function jumlahkegiatan($tahun, $kd_subunit = null)
    {
        if ($kd_subunit == null) {
            $data = $this
                ->select('nm_kegiatan')
                ->where('tahun', $tahun)
                ->where('pagu_rincian<>', '0')
                ->groupBy('nm_kegiatan')
                ->get()
                ->getResultArray();
        } else {
            $data = $this
                ->select('nm_kegiatan')
                ->where('tahun', $tahun)
                ->where('kd_sub_unit', $kd_subunit)
                ->where('pagu_rincian<>', '0')
                ->groupBy('nm_kegiatan')
                ->get()
                ->getResultArray();
        }
        return  $data;
    }
    public function jumlahsubkegiatan($tahun, $kd_subunit = null)
    {
        if ($kd_subunit == null) {
            $data = $this
                ->select('nm_subkegiatan')
                ->where('tahun', $tahun)
                ->where('pagu_rincian<>', '0')
                ->groupBy('nm_subkegiatan')
                ->get()
                ->getResultArray();
        } else {
            $data = $this
                ->select('nm_subkegiatan')
                ->where('tahun', $tahun)
                ->where('kd_sub_unit', $kd_subunit)
                ->where('pagu_rincian<>', '0')
                ->groupBy('nm_subkegiatan')
                ->get()
                ->getResultArray();
        }
        return  $data;
    }
    public function belatk($kdSU)
    {
        return $this
            ->selectSum('pagu_rincian')
            ->where('pagu_rincian<>', '0')
            ->where('nm_sub_unit', $kdSU)
            ->like('nm_rekening', 'Alat Tulis Kantor')
            ->get()
            ->getRowArray();
    }

    public function belcetak($kdSU)
    {
        return $this
            ->selectSum('pagu_rincian')
            ->where('pagu_rincian<>', '0')
            ->where('nm_sub_unit', $kdSU)
            ->like('nm_rekening', 'Bahan Cetak')
            ->get()
            ->getRowArray();
    }
    public function belsppd($kdSU)
    {
        return $this
            ->selectSum('pagu_rincian')
            ->where('pagu_rincian<>', '0')
            ->where('nm_sub_unit', $kdSU)
            ->like('nm_rekening', 'Perjalanan Dinas')
            ->get()
            ->getRowArray();
    }
    public function totpaguopd2($kdSU)
    {
        return $this
            ->selectSum('pagu_rincian')
            ->where('pagu_rincian<>', '0')
            ->where('nm_sub_unit', $kdSU)
            ->get()
            ->getRowArray();
    }
    public function totpaguopd($kdSU)
    {
        return $this
            ->selectSum('pagu_rincian')
            ->selectCount('kd_rek_belanja')
            ->where('pagu_rincian<>', '0')
            ->where('kd_sub_unit', $kdSU)
            ->get()
            ->getRowArray();
    }

    public function urusanopd($kdSU, $kdU)
    {
        return $this
            ->select('*')
            ->selectSum('pagu_rincian')
            ->where('pagu_rincian<>', '0')
            ->where('kd_urusan', $kdU)
            ->where('kd_sub_unit', $kdSU)
            ->groupBy('kd_urusan')
            ->get()
            ->getRowArray();
    }

    public function programopd($kdSU)
    {
        return $this
            ->where('pagu_rincian<>', '0')
            ->where('kd_sub_unit', $kdSU)
            ->groupBy('kd_program')
            ->get()
            ->getResultArray();
    }
    public function subkegiatanperopd($kdSU)
    {
        return $this
            ->where('pagu_rincian<>', '0')
            ->where('kd_sub_unit', $kdSU)
            ->groupBy('kd_subkegiatan')
            ->get()
            ->getResultArray();
    }
    public function SKKegPokokOPD2($kdSU)
    {
        return $this
            ->select('*')
            ->where('pagu_rincian<>', '0')
            ->where('kd_sub_unit', $kdSU)
            ->where('nm_program<>', 'PROGRAM PENUNJANG URUSAN PEMERINTAHAN DAERAH PROVINSI')
            ->groupBy('kd_subkegiatan')
            ->get()
            ->getResultArray();
    }
    public function SKKegPokokOPD($kdSU)
    {
        $products = $this->select('*')
            ->where('pagu_rincian<>', '0')
            ->where('kd_sub_unit', $kdSU)
            ->where('nm_program<>', 'PROGRAM PENUNJANG URUSAN PEMERINTAHAN DAERAH PROVINSI')
            ->groupBy('kd_subkegiatan')
            ->get()
            ->getResultArray(); //$this->findAll();
        $options = [];

        foreach ($products as $key => $product) {
            $options[$product['id'] = $product['id'] . ' (' . $product['nm_subkegiatan'] . ')'];
        }

        return $options;
    }
    public function perprogramopd($kdSU, $kdP)
    {
        return $this
            ->where('pagu_rincian<>', '0')
            ->where('kd_sub_unit', $kdSU)
            ->where('kd_program', $kdP)
            ->get()
            ->getRowArray();
    }

    public function subkeg($kdSK, $kdSU)
    {
        return $this
            ->select('*')->selectSum('pagu_rincian')
            ->where('pagu_rincian<>', '0')
            ->where('kd_subkegiatan', $kdSK)
            ->where('kd_sub_unit', $kdSU)
            ->groupBy('kd_subkegiatan')
            //  ->orderBy('kd_sub_unit', 'ASC')
            ->get()
            ->getRowArray();
    }
    public function pagusubkeg($kdSK, $kdSU)
    {
        return $this
            ->selectSum('pagu_rincian')
            ->where('pagu_rincian<>', '0')
            ->where('kd_subkegiatan', $kdSK)
            ->where('kd_sub_unit', $kdSU)
            ->groupBy('kd_subkegiatan')
            ->get()
            ->getRowArray();
    }


    public function subkegbelanja($kdSK, $kdSU)
    {
        return $this
            ->where('pagu_rincian<>', '0')
            ->where('kd_subkegiatan', $kdSK)
            ->where('kd_sub_unit', $kdSU)

            //  ->groupBy('nm_program')
            //  ->orderBy('kd_sub_unit', 'ASC')
            ->get()
            ->getResultArray();
    }
    public function listopd($nm_sub_unit = null)
    {
        if ($nm_sub_unit == null) {
            $q =  $this
                ->select('kd_skpd,kd_sub_unit,nm_sub_unit')
                ->where('pagu_rincian<>', '0')
                ->groupBy('nm_sub_unit')
                ->orderBy('kd_sub_unit', 'ASC')
                ->get()
                ->getResultArray();
        } else {
            $q = $this
                ->select('kd_skpd,kd_sub_unit,nm_sub_unit')
                ->where('pagu_rincian<>', '0')
                ->where('nm_sub_unit', $nm_sub_unit)
                ->groupBy('nm_sub_unit')
                ->get()
                ->getRowArray();
        }
        return $q;
    }
    public function listprogram($opd, $kd_sub_unit)
    {
        return $this->select('*')->selectSUM('pagu_rincian')->where('pagu_rincian<>', '0')
            ->where('nm_sub_unit', $opd)
            ->where('kd_sub_unit', $kd_sub_unit)
            ->groupBy('kd_urusan')
            ->where('pagu_rincian<>', '0')
            ->get()
            ->getResultArray();
    }
    public function listapbd($opd)
    {
        return $this
            ->where('pagu_rincian<>', '0')
            ->where('nm_sub_unit', $opd)
            ->where('pagu_rincian<>', '0')
            ->get()
            ->getResultArray();
    }
    public function paguperurusan($opd, $kd_sub_unit)
    {
        return $this
            ->select('*')
            ->selectSum('pagu_rincian')
            ->where('nm_sub_unit', $opd)
            ->where('kd_sub_unit', $kd_sub_unit)
            ->groupBy('kd_urusan')
            ->where('pagu_rincian<>', '0')
            ->get()
            ->getResultArray();
    }
}
