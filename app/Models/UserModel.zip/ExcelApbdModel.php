<?php

namespace App\Models;

use CodeIgniter\Model;

class ExcelApbdModel extends Model
{
    protected $table = 'ta_apbd_perbelanja2';
    protected $primaryKey = 'id';


    // Fungsi untuk insert batch data
    public function insertBatchData(array $data)
    {
        return $this->insertBatch($data);
    }
}
