<?= $this->extend('template/layout') ?>
<?= $this->section('content') ?>
<div class="container-fluid">
    <!-- SELECT2 EXAMPLE -->
    <div class="card card-default">
        <div class="card card-primary card-outline mb-4">
            <!--begin::Header-->
            <div class="card-header">
                <div class="card-title">
                    <?php if (!$idUbah) { ?>
                        Form Input Target Sasaran Kegiatan Pokok
                    <?php } ?>
                    <?php if ($idUbah) { ?>
                        Form Ubah SubKegiatan Kegiatan Pokok
                    <?php } ?>

                </div>
            </div>
            <!--end::Header-->
            <!--begin::Form-->
            <?= form_open_multipart('capkin/simpan'); ?>
            <?= csrf_field(); ?>
            <!--begin::Body-->
            <div class="card-body">
                <div id="input-container">
                    <div class="mb-3">
                        <label for="subkegiatan" class="form-label">SUBKEGIATAN</label>
                        <?= form_dropdown('kd_subkegiatan', $sknoadum, $inputs['kd_subkegiatan'] ?? null, ['class' => 'form-select']);
                        //form_dropdown('sub_keg', $sknoadum); 
                        ?>
                        <?= form_hidden('kd_subunit', $kd_subunit); ?>
                        <?= form_hidden('idUbah', $idUbah); ?>

                    </div>
                    <br>
                    <div class="mb-3">
                        <div class="d-flex justify-content-between mt-4">
                            <div>
                                <?php if (!$idUbah) { ?>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="bi bi-plus-circle"></i> Tambah Kegiatan Pokok
                                    </button>
                                <?php } ?>
                                <?php if ($idUbah) { ?>
                                    <button type="submit" class="btn btn-primary">
                                        <i class="bi bi-edit-circle"></i> SIMPAN PERUBAHAN
                                    </button>
                                <?php } ?>

                            </div>
                        </div>
                    </div>
                </div>
                <!--end::Footer-->
                <?= form_close(); ?>
                <!--end::Form-->
            </div>
            <!--end::Quick Example-->
        </div>
    </div>

    <?= $this->endSection() ?>
    <!-- /.card -->