<?= $this->extend('template/layout') ?>
<?= $this->section('content') ?>
<!--begin::Container-->
<?php

use App\Models\CapkinModel\TaKegPokokCapkinModel;

$this->kegpokokmodal = new TaKegPokokCapkinModel();


?>
<div class="container-fluid">
    <!--begin::Row-->
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Kegiatan Pokok Perangkat Daerah <?= esc($datauser['sub_unit']) ?></h3>
                </div>

                <!-- /.card-header -->
                <!-- <div class="card-body"> -->
                <div class="card-body table-responsive p-0" style="height: 500px;">
                    <a
                        href="<?= hash_url('capkin', ['page' => 'data', 'action' => 'tambah']);
                                ?>" class="nav-link">
                        <button type="button" class="btn btn-outline-primary mb-2">TAMBAH SUBKEGIATAN</button>
                    </a>
                    <table id="example1" class="table table-head-fixed table-bordered table-striped text-wrap" style="border: black;">
                        <thead>
                            <tr style="text-align: center;">
                                <th rowspan="2" style="text-align: justify;">Program/Kegiatan/SubKegiatan</th>
                                <th colspan="2">Kegiatan Pokok SubKegiatan</th>
                                <th colspan="2">Anggaran</th>
                                <th colspan="2">Realisasi Kegiatan Pokok</th>
                                <th rowspan="2">Lokasi Kegiatan</th>
                                <th rowspan="2">#</th>

                            </tr>
                            <tr style="text-align: center;">
                                <th>Sasaran/Target <?= esc($tahun) ?></th>
                                <th>Uraian</th>
                                <th>Pagu Subkegiatan</th>
                                <th>Realisasi</th>
                                <th>Sasaran</th>
                                <th>Uraian Realisasi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php
                            foreach ($dataskcapkinopd as $key => $dataskcapkin) { ?>
                                <tr>
                                    <td>
                                        <?= esc($dataskcapkin['kd_program'])  ?><br>
                                        <?= esc($dataskcapkin['kd_kegiatan'])  ?><br>
                                        <?= esc($dataskcapkin['kd_subkegiatan'])  ?><br>
                                        <?= esc($dataskcapkin['nm_subkegiatan'])  ?>
                                        <?= esc($dataskcapkin['id'])  ?>

                                    </td>
                                    <td>Internet
                                        Explorer 4.0
                                    </td>
                                    <td>Win 95+</td>
                                    <td><?= esc($dataskcapkin['pagu'])  ?></td>
                                    <td>X</td>
                                    <td>X</td>
                                    <td>X</td>
                                    <td>X</td>
                                    <td>
                                        <div class="btn-group">
                                            <button
                                                type="button"
                                                class="btn btn dropdown-toggle"
                                                data-bs-toggle="dropdown"
                                                aria-expanded="false">
                                                <i class="bi bi-plus-circle"></i>MENU</button>
                                            </button>
                                            <ul class="dropdown-menu">
                                                <?php
                                                $cekkegpokok = $this->kegpokokmodal->DataPerIdSK($dataskcapkin['id']);
                                                if (!$cekkegpokok) { ?>
                                                    <li><a class="dropdown-item"
                                                            href="<?= hash_url('capkin/kegpokok', [
                                                                        'page' => 'kegpokok',
                                                                        'action' => 'tambah',
                                                                        'idSK' => $dataskcapkin['id']
                                                                    ]);
                                                                    ?>">
                                                            <i class="bi bi-plus-circle"></i>Tambah Keg.Pokok</a></li>
                                                <?php }
                                                ?>
                                            </ul>
                                        </div>


                                    </td>

                                </tr>

                            <?php
                            }
                            ?>
                        </tbody>
                        <!-- <tfoot>
                            <tr>
                                <th>Rendering engine</th>
                                <th>Browser</th>
                                <th>Platform(s)</th>
                                <th>Engine version</th>
                                <th>CSS grade</th>
                                <th>Engine version</th>
                                <th>CSS grade</th>
                                <th>Engine version</th>
                            </tr>
                        </tfoot> -->
                    </table>
                </div>
                <!-- /.card-body -->
            </div>
            <!-- /.card -->
        </div>
        <!-- /.col -->
    </div>
    <!-- /.row -->
</div>


<?= $this->endSection() ?>