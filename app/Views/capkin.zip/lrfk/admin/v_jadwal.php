<?= $this->extend('template/layout') ?>
<?= $this->section('content') ?>
<div class="container-fluid">

    <div class="row">
        <div class="col-md-6">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Jadwal Input Data yang aktif saat ini ::</h3>
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th style="width: 10px">#</th>
                                <th>TAHUN</th>
                                <th>BULAN</th>
                                <th style="width: 40px">Status</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <td>1.</td>
                                <td><?= $jadwalaktif['tahun'] ?? null;  ?></td>
                                <td>
                                    <?= $jadwalaktif['bulan'] ?? null; ?>
                                </td>
                                <td>
                                    <input type="checkbox" class="form-check-input" id="exampleCheck1" checked />
                                    <label class="form-check-label" for="exampleCheck1">
                                        <a
                                            href="<?= hash_url('lrfkadmin/jadwaladmin/', ['action' => 'ganti']); ?>"
                                            rel="noopener noreferrer"
                                            class="callout-link">
                                            Ganti Jadwal Aktif
                                        </a>
                                    </label>
                                </td>
                            </tr>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </div>
</div>
<!-- /.card -->
<?= $this->endSection() ?>