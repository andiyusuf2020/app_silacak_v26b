<?= $this->extend('template/layout') ?>
<?= $this->section('content') ?>
<!--begin::Container-->
<div class="container-fluid">
    <!-- /.col-md-6 -->
    <div class="row">
        <?php if (session()->getFlashdata('message')): ?>
            <div class="alert alert-primary" role="alert">
                <ul>
                    <p><?= session()->getFlashdata('message') ?></p>
                </ul>
            </div>
        <?php endif; ?>
        <?php if (session()->has('errors')): ?>
            <div class="alert alert-danger" role="alert">
                <ul>
                    <?php foreach (session('errors') as $error): ?>
                        <li><?= esc($error) ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
        <?php endif; ?>

        <div class="col-md-12 col-sm-12  ">
            <div class="x_panel">
                <div class="x_title">
                    <h2>Grafik Capaian Anggaran</h2>
                    <div class="clearfix"></div>
                </div>
                <div class="x_content">
                    <div id="rpertahun" style="height:500px;"></div>
                </div>
            </div>
        </div>
    </div>
    <div class="row">
        <div class="col-lg-6">
            <div class="card mb-4">
                <div class="card-header">
                    <h3 class="card-title">Komposisi Belanja Kegiatan Pendukung</h3>
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                    <!--begin::Row-->
                    <div class="row">
                        <div class="col-12">
                            <div id="pie-chart"></div>
                        </div>
                        <!-- /.col -->
                    </div>
                    <!--end::Row-->
                </div>
                <!-- /.card-body -->
                <div class="card-footer p-0">
                    <ul class="nav nav-pills flex-column">
                        <li class="nav-item">
                            <a href="#" class="nav-link">
                                Belanja Alat Tulis Kantor
                                <span class="float-end text-danger">
                                    <i class="bi bi-arrow-down fs-7"></i>
                                    <?= number_format(esc($atk), 2, '.', ',') . ' %'; ?>
                                </span>
                                <span class="float-end text-danger">
                                    <?= 'Rp. ' . number_format(esc($rpatk), 2, '.', ','); ?>
                                </span>

                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#" class="nav-link">
                                Belanja Cetak
                                <span class="float-end text-success">
                                    <i class="bi bi-arrow-up fs-7"></i>
                                    <?= number_format(esc($cetak), 2, '.', ',') . ' %'; ?>
                                </span>
                                <span class="float-end text-danger">
                                    <?= 'Rp. ' . number_format(esc($rpcetak), 2, '.', ','); ?>
                                </span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#" class="nav-link">
                                Belanja Perjalanan Dinas
                                <span class="float-end text-info">
                                    <i class="bi bi-arrow-left fs-7"></i>
                                    <?= number_format(esc($sppd), 2, '.', ',') . ' %'; ?>
                                </span>
                                <span class="float-end text-danger">
                                    <?= 'Rp. ' . number_format(esc($rpsppd), 2, '.', ','); ?>
                                </span>

                            </a>
                        </li>
                    </ul>
                </div>
            </div>

        </div>
        <div class="col-lg-6">
            <div class="card mb-4">
                <div class="card-header">
                    <h3 class="card-title">Komposisi Belanja Pendukung Kegiatan</h3>
                </div>
                <!-- /.card-header -->
                <div class="card-body">
                    <!--begin::Row-->
                    <div class="row">
                        <div class="col-12">
                            <div id="pie-chart"></div>
                        </div>
                        <!-- /.col -->
                    </div>
                    <!--end::Row-->
                </div>
                <!-- /.card-body -->
                <div class="card-footer p-0">
                    <ul class="nav nav-pills flex-column">
                        <li class="nav-item">
                            <a href="#" class="nav-link">
                                Belanja Alat Tulis Kantor
                                <span class="float-end text-danger">
                                    <i class="bi bi-arrow-down fs-7"></i>
                                    <?= number_format(esc($atk), 2, '.', ',') . ' %'; ?>
                                </span>
                                <span class="float-end text-danger">
                                    <?= 'Rp. ' . number_format(esc($rpatk), 2, '.', ','); ?>
                                </span>

                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#" class="nav-link">
                                Belanja Cetak
                                <span class="float-end text-success">
                                    <i class="bi bi-arrow-up fs-7"></i>
                                    <?= number_format(esc($cetak), 2, '.', ',') . ' %'; ?>
                                </span>
                                <span class="float-end text-danger">
                                    <?= 'Rp. ' . number_format(esc($rpcetak), 2, '.', ','); ?>
                                </span>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="#" class="nav-link">
                                Belanja Perjalanan Dinas
                                <span class="float-end text-info">
                                    <i class="bi bi-arrow-left fs-7"></i>
                                    <?= number_format(esc($sppd), 2, '.', ',') . ' %'; ?>
                                </span>
                                <span class="float-end text-danger">
                                    <?= 'Rp. ' . number_format(esc($rpsppd), 2, '.', ','); ?>
                                </span>

                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
    <!--end::Row-->
</div>
<style>
    /* CSS untuk memastikan ukuran carousel tetap */
    .fixed-size-carousel {
        width: 1200px;
        /* Sesuaikan dengan lebar yang diinginkan */
        height: 450px;
        /* Sesuaikan dengan tinggi yang diinginkan */
        margin: 0 auto;
    }

    .fixed-size-carousel .carousel-inner,
    .fixed-size-carousel .carousel-item {
        width: 100%;
        height: 100%;
    }

    .fixed-size-carousel .carousel-item img {
        width: 150%;
        height: 150%;
        object-fit: cover;
        /* Memastikan gambar menutupi area tanpa kehilangan proporsi */
    }
</style>

<script src="<?= base_url() ?>vendors/echarts/dist/echarts.min.js"></script>
<script type="text/javascript">
    var dom = document.getElementById("rpertahun");
    var myChart = echarts.init(dom);
    var app = {};

    var option;

    option = {
        title: {
            text: 'Tren Realisasi Anggaran 5 tahun terakhir',
            subtext: '<?= esc($value['sub_unit'] ?? null) ?>'
        },
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            data: ['% Realisasi']
        },
        toolbox: {
            show: true,
            feature: {
                dataView: {
                    show: true,
                    readOnly: false
                },
                magicType: {
                    show: true,
                    type: ['line', 'bar']
                },
                restore: {
                    show: true
                },
                saveAsImage: {
                    show: true
                }
            }
        },
        calculable: true,
        xAxis: [{
            type: 'category',
            // prettier-ignore
            data: ['2020', '2021', '2022', '2023', '2024']
        }],
        yAxis: [{
            type: 'value'
        }],
        series: [{
            name: '% Realisasi',
            type: 'bar',
            data: [<?php
                    $string = implode(', ', $datarealpertahun);
                    echo esc($string);
                    ?>],

            markPoint: {
                data: [{
                        type: 'max',
                        name: 'Max'
                    },
                    {
                        type: 'min',
                        name: 'Min'
                    }
                ]
            },
            markLine: {
                data: [{
                    type: 'average',
                    name: 'Avg'
                }]
            }
        }, ]
    };

    if (option && typeof option === 'object') {
        myChart.setOption(option);
    }
</script>

<script type="text/javascript">
    var dom = document.getElementById("container");
    var myChart = echarts.init(dom);
    var app = {};

    var option;

    option = {
        title: {
            text: 'Rainfall vs Evaporation',
            subtext: 'Fake Data'
        },
        tooltip: {
            trigger: 'axis'
        },
        legend: {
            data: ['Rainfall', 'Evaporation']
        },
        toolbox: {
            show: true,
            feature: {
                dataView: {
                    show: true,
                    readOnly: false
                },
                magicType: {
                    show: true,
                    type: ['line', 'bar']
                },
                restore: {
                    show: true
                },
                saveAsImage: {
                    show: true
                }
            }
        },
        calculable: true,
        xAxis: [{
            type: 'category',
            // prettier-ignore
            data: ['Jan', 'Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec']
        }],
        yAxis: [{
            type: 'value'
        }],
        series: [{
                name: 'Rainfall',
                type: 'bar',
                data: [
                    2.0, 4.9, 7.0, 23.2, 25.6, 76.7, 135.6, 162.2, 32.6, 20.0, 6.4, 3.3
                ],
                markPoint: {
                    data: [{
                            type: 'max',
                            name: 'Max'
                        },
                        {
                            type: 'min',
                            name: 'Min'
                        }
                    ]
                },
                markLine: {
                    data: [{
                        type: 'average',
                        name: 'Avg'
                    }]
                }
            },
            {
                name: 'Evaporation',
                type: 'bar',
                data: <?php
                        function convertStringsToNumbers($value)
                        {
                            if (is_array($value)) {
                                return array_map('convertStringsToNumbers', $value);
                            }
                            if (is_string($value)) {
                                if (is_numeric($value)) {
                                    return strpos($value, '.') === false ? (int)$value : (float)$value;
                                }
                            }
                            return $value;
                        }
                        $convertedData = convertStringsToNumbers($datarealpertahun);
                        $json = json_encode($convertedData);
                        echo '[' . $json . ']'; ?>,
                markPoint: {
                    data: [{
                            name: 'Max',
                            value: 182.2,
                            xAxis: 7,
                            yAxis: 183
                        },
                        {
                            name: 'Min',
                            value: 2.3,
                            xAxis: 11,
                            yAxis: 3
                        }
                    ]
                },
                markLine: {
                    data: [{
                        type: 'average',
                        name: 'Avg'
                    }]
                }
            }
        ]
    };

    if (option && typeof option === 'object') {
        myChart.setOption(option);
    }
</script>

<script type="text/javascript">
    var dom = document.getElementById("container2");
    var myChart = echarts.init(dom);
    var app = {};

    var option;



    option = {
        title: {
            text: 'Nightingale Chart',
            subtext: 'Fake Data',
            left: 'center'
        },
        tooltip: {
            trigger: 'item',
            formatter: '{a} <br/>{b} : {c} ({d}%)'
        },
        legend: {
            left: 'center',
            top: 'bottom',
            data: [
                'rose1',
                'rose2',
                'rose3',
                'rose4',
                'rose5',
                'rose6',
                'rose7',
                'rose8'
            ]
        },
        toolbox: {
            show: true,
            feature: {
                mark: {
                    show: true
                },
                dataView: {
                    show: true,
                    readOnly: false
                },
                restore: {
                    show: true
                },
                saveAsImage: {
                    show: true
                }
            }
        },
        series: [{
            name: 'Area Mode',
            type: 'pie',
            radius: [20, 140],
            center: ['50%', '50%'],
            roseType: 'area',
            itemStyle: {
                borderRadius: 5
            },
            data: [{
                    value: 30,
                    name: 'rose 1'
                },
                {
                    value: 28,
                    name: 'rose 2'
                },
                {
                    value: 26,
                    name: 'rose 3'
                },
                {
                    value: 24,
                    name: 'rose 4'
                },
                {
                    value: 22,
                    name: 'rose 5'
                },
                {
                    value: 20,
                    name: 'rose 6'
                },
                {
                    value: 18,
                    name: 'rose 7'
                },
                {
                    value: 16,
                    name: 'rose 8'
                }
            ]
        }]
    };

    if (option && typeof option === 'object') {
        myChart.setOption(option);
    }
</script>
<!--end::Container-->
<!-- OPTIONAL SCRIPTS -->
<!-- apexcharts -->
<script
    src="https://cdn.jsdelivr.net/npm/apexcharts@3.37.1/dist/apexcharts.min.js"
    integrity="sha256-+vh8GkaU7C9/wbSLIcwq82tQ2wTf44aOHA8HlBMwRI8="
    crossorigin="anonymous"></script>
<script>
    // NOTICE!! DO NOT USE ANY OF THIS JAVASCRIPT
    // IT'S ALL JUST JUNK FOR DEMO
    // ++++++++++++++++++++++++++++++++++++++++++

    const visitors_chart_options = {
        series: [{
                name: 'High - 2023',
                data: [100, 120, 170, 167, 180, 177, 160],
            },
            {
                name: 'Low - 2023',
                data: [60, 80, 70, 67, 80, 77, 100],
            },
        ],
        chart: {
            height: 200,
            type: 'line',
            toolbar: {
                show: false,
            },
        },
        colors: ['#0d6efd', '#adb5bd'],
        stroke: {
            curve: 'smooth',
        },
        grid: {
            borderColor: '#e7e7e7',
            row: {
                colors: ['#f3f3f3', 'transparent'], // takes an array which will be repeated on columns
                opacity: 0.5,
            },
        },
        legend: {
            show: false,
        },
        markers: {
            size: 1,
        },
        xaxis: {
            categories: ['22th', '23th', '24th', '25th', '26th', '27th', '28th'],
        },
    };

    const visitors_chart = new ApexCharts(
        document.querySelector('#visitors-chart'),
        visitors_chart_options,
    );
    visitors_chart.render();

    const r_chart_options = {
        series: [{
                name: 'Net Profit',
                data: [44, 55, 57, 56, 61, 58, 63, 60, 66],
            },
            {
                name: 'Revenue',
                data: [76, 85, 101, 98, 87, 105, 91, 114, 94],
            },
            {
                name: 'Free Cash Flow',
                data: [35, 41, 36, 26, 45, 48, 52, 53, 41],
            },
        ],
        chart: {
            type: 'bar',
            height: 200,
        },
        plotOptions: {
            bar: {
                horizontal: false,
                columnWidth: '55%',
                endingShape: 'rounded',
            },
        },
        legend: {
            show: false,
        },
        colors: ['#0d6efd', '#20c997', '#ffc107'],
        dataLabels: {
            enabled: false,
        },
        stroke: {
            show: true,
            width: 2,
            colors: ['transparent'],
        },
        xaxis: {
            categories: ['Feb', 'Mar', 'Apr', 'Mei', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct'],
        },
        fill: {
            opacity: 1,
        },
        tooltip: {
            y: {
                formatter: function(val) {
                    return '$ ' + val + ' thousands';
                },
            },
        },
    };

    const r_chart = new ApexCharts(
        document.querySelector('#rchart'),
        r_chart_options,
    );
    r_chart.render();
</script>
<script>
    //-------------
    // - PIE CHART -
    //-------------

    const pie_chart_options = {
        series: [<?= number_format(esc($atk), 2, '.', ','); ?>,
            <?= number_format(esc($cetak), 2, '.', ','); ?>,
            <?= number_format(esc($sppd), 2, '.', ','); ?>
        ],
        chart: {
            type: 'donut',
        },
        labels: ['Bel.ATK', 'Bel.Cetak', 'Bel.PerDin'],
        //labels: ['Bel.ATK', 'Bel.Cetak', 'Bel.PerDin', 'Safari', 'Opera', 'IE'],

        dataLabels: {
            enabled: false,
        },
        // colors: ['#0d6efd', '#20c997', '#ffc107', '#d63384', '#6f42c1', '#adb5bd'],
        colors: ['#0d6efd', '#20c997', '#ffc107'],
    };

    const pie_chart = new ApexCharts(document.querySelector('#pie-chart'), pie_chart_options);
    pie_chart.render();

    //-----------------
    // - END PIE CHART -
    //-----------------
</script>
<?= $this->endSection() ?>